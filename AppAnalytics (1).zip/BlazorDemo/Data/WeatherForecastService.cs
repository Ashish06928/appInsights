using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

using LogAnalytics.Client;
using Microsoft.Extensions.Logging;

namespace BlazorDemo.Data
{
    public class WeatherForecastService
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly LogAnalyticsClient _logger;

        private readonly ILogger<WeatherForecast> _logger1;

        public WeatherForecastService(LogAnalyticsClient logger, ILogger<WeatherForecast> logger1)
        {
            _logger = logger;
            _logger1 = logger1;
        }

        public async Task<List<WeatherForecast>> GetForecastAsync(DateTime startDate)
        {
            var rng = new Random();
            var iteration = 1;
            _logger1.LogDebug($"Debug {iteration}");
            _logger1.LogInformation($"Information {iteration}");
            _logger1.LogWarning($"Warning {iteration}");
            _logger1.LogError($"Error {iteration}");
            _logger1.LogCritical($"Critical {iteration}");
            var forecast = Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = startDate.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]


            }).ToList();
            foreach (var (item, index) in forecast.Select((value, i) => (value, i)))
            {
                using (SqlConnection openCon = new SqlConnection(@"Server=tcp:dbserver874.database.windows.net,1433;Initial Catalog=db01;Persist Security Info=False;User ID=dbdemo;Password=Welcome@12345;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30"))
                {
                    string saveFoarcast = "DELETE FROM forcaste";

                    using (SqlCommand querySaveForcaste = new SqlCommand(saveFoarcast))
                    {
                        querySaveForcaste.Connection = openCon;
                        openCon.Open();
                        querySaveForcaste.ExecuteNonQuery();
                    }
                }
            }

            foreach (var (item, index) in forecast.Select((value, i) => (value, i)))
            {
                using (SqlConnection openCon = new SqlConnection(@"Server=tcp:dbserver874.database.windows.net,1433;Initial Catalog=db01;Persist Security Info=False;User ID=dbdemo;Password=Welcome@12345;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30"))
                {
                    string saveFoarcast = "INSERT into forcaste (ID,Date,Temp,Summary) VALUES (@ID,@Date,@Temp,@Summary)";

                    using (SqlCommand querySaveForcaste = new SqlCommand(saveFoarcast))
                    {
                        querySaveForcaste.Connection = openCon;
                        querySaveForcaste.Parameters.Add("@ID", SqlDbType.Int).Value = rng.Next();
                        querySaveForcaste.Parameters.Add("@Date", SqlDbType.DateTime).Value = startDate.AddDays(index);
                        querySaveForcaste.Parameters.Add("@Temp", SqlDbType.NVarChar).Value = rng.Next(-20, 55);
                        querySaveForcaste.Parameters.Add("@Summary", SqlDbType.NVarChar).Value = Summaries[rng.Next(Summaries.Length)];
                        openCon.Open();
                        querySaveForcaste.ExecuteNonQuery();
                    }
                }
            }
            // send weather forecasts in to Log Analytics
            await _logger.SendLogEntries(forecast, "forecasts");

            return forecast;
        }
    }
}
